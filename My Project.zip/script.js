// عند الضغط على الزر، يتم تغيير لون الخلفية
const button = document.getElementById("changeColor");

button.addEventListener("click", function () {
    // توليد لون عشوائي
    const randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16);
    document.body.style.backgroundColor = randomColor;
    console.log("تم تغيير لون الخلفية إلى:", randomColor);
});